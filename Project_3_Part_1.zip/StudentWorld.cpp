#include "StudentWorld.h"
#include <string>
using namespace std;

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}


StudentWorld :: StudentWorld(string assetDir): GameWorld(assetDir)
{
}


StudentWorld :: ~StudentWorld()
{
    for (int k = 0; k < 64; k++)
    {
        delete dirty[k][k];
    }
    
    delete player;
}


int StudentWorld :: init()
{
    for (int k = 0; k < 64; k++)
    {
        for (int j = 0; j < 60; j++)
        {
            if (j < 4)
            dirty[k][j] = new Dirt(k, j, this);
            else if (k < 30 || k > 33)
            dirty[k][j] = new Dirt(k, j, this);
            else
            dirty[k][j] = nullptr;
        }
    }
    
    player = new FrackMan(30,60, Actor::up, this);
    
    return GWSTATUS_CONTINUE_GAME;
}


int StudentWorld:: move()
{
    //updateDisplayText();
    
    if (getLives() == 0)
    {
        return GWSTATUS_PLAYER_DIED;
    }
    
    player->doSomething();
    

    return GWSTATUS_CONTINUE_GAME;
}


void StudentWorld:: cleanUp()
{
    for (int k = 0; k < 64; k++)
    {
        deleteDirt(k, k);
    }
    
    delete player;
}

bool StudentWorld:: deleteDirt(int x,int y)
{
    if (dirty[x][y] != nullptr)
    {
        delete dirty[x][y];
        dirty[x][y] = nullptr;
        return true;
    }
    return false;
}

void StudentWorld:: setDisplayText() {
    /*int score = getScore();
    int level = getLevel();
    int lives = getLives();
    //int health = getCurrentHealth();
    //int squirts = getSquirtsLeftInSquirtGun();
    //int gold = getPlayerGoldCount();
    //int sonar = getPlayerSonarChargeCount();
    //int barrelsLeft = getNumberOfBarrelsRemainingToBePickedUp();
    // Next, create a string from your statistics, of the form:
    
  string s = "Scr: " + score + " Lvl: " + level + " Lives: " + lives + "Hlth: " + " Water: " + " Gld: " + " Sonar " + " Oil Left: ";

    setGameStatText(s); // calls our provided GameWorld::setGameStatText*/
}
