#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

//////////////// Base Actor class for all objects /////////////////////

Actor :: Actor (int imageID, int x, int y, Direction dir, double size, int depth, StudentWorld* world, bool visible) : GraphObject(imageID, x, y, dir, size, depth)
{
    setVisible(visible);
    worldy = world;
}

Actor :: ~Actor()
{
}

void Actor:: getsAnnoyed()
{
}

bool Actor:: isDead()
{
    return dead;
}

StudentWorld* Actor:: getWorld()
{
    return worldy;
}

////////////////////////////////////////////////////////////////////////

///////////// FrackMan player class /////////////////////////////
FrackMan :: FrackMan(int x, int y, Direction dir, StudentWorld* world) : Actor(IID_PLAYER, 30,60,right,1,0,world,true)
{
    m_health = 10;
    m_sonar = 1;
    m_water = 5;
    m_gold = 0;
}

FrackMan :: ~FrackMan()
{
}

void FrackMan:: doSomething()
{
    if (isDead() == true)
        return;
    
    for (int k = getX(); k < getX()+4; k++)
        for (int j = getY(); j < getY()+4; j++)
            getWorld()->deleteDirt(k, j);
    
    
    int k;
    if (getWorld()->getKey(k))
    {
        switch (k)
        {
            case KEY_PRESS_LEFT:
                if (getDirection() != left)
                    setDirection(left);
                else if (getX() > 0)
                    moveTo(getX()-1, getY());
                break;
            case KEY_PRESS_RIGHT:
                if (getDirection() != right)
                    setDirection(right);
                else if (getX() < 60)
                    moveTo(getX()+1, getY());
                break;
            case KEY_PRESS_UP:
                if (getDirection() != up)
                    setDirection(up);
                else if (getY() < 60)
                    moveTo(getX(), getY()+1);
                break;
            case KEY_PRESS_DOWN:
                if (getDirection() != down)
                    setDirection(down);
                else if (getY() > 0)
                    moveTo(getX(), getY()-1);
                break;
            case KEY_PRESS_SPACE:
                break;
        }
    }
    
    
}

void FrackMan:: getAnnoyed()
{
}

/////////////////////////////////////////////////////////////////////////


/////////////////////////// Dirt class //////////////////////////////////
Dirt :: Dirt(int x, int y, StudentWorld* world) : Actor(IID_DIRT, x,y,right,.25,3,world,true)
{
}

Dirt :: ~Dirt()
{
}

/////////////////////////////////////////////////////////////////////


