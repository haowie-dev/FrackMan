#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"


// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
    Actor(int imageID, int x, int y, Direction dir, double size, int depth, StudentWorld* world, bool visible);
    ~Actor();
    virtual void doSomething() = 0;
    virtual void getsAnnoyed();
    virtual bool isDead();
    StudentWorld* getWorld();
    
private:
    bool dead;
    StudentWorld* worldy;
};


class FrackMan : public Actor
{
public:
    FrackMan(int x, int y, Direction dir, StudentWorld* world);
    ~FrackMan();
    virtual void doSomething();
    virtual void getAnnoyed();
    
private:
    int m_health;
    int m_water;
    int m_sonar;
    int m_gold;
};


class Dirt : public Actor
{
public:
    Dirt(int x, int y, StudentWorld* world);
    ~Dirt();
    virtual void doSomething() {};
    
private:
};



#endif // ACTOR_H_
